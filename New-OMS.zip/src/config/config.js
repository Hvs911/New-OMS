export const SERVER_URL = "http://localhost:8080/user";


export const DEFAULT_BLUR_URL =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAACklEQVR4nGMAAQAABQABDQottAAAAABJRU5ErkJggg==";

export const IMAGE_URL = "https://storage.googleapis.com/bucket-name/";
