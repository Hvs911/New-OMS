// Defining the configuration for the branded authentication layout
const authLayoutBrandedConfig = {
  // Setting the layout name to 'auth-branded'
  name: 'auth-branded',
  // Currently no additional options defined, but this object can be extended in the future
  options: {}
};
export { authLayoutBrandedConfig };